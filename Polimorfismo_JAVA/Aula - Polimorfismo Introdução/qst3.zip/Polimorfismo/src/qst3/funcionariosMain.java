package qst3;
import java.util.ArrayList;
import java.util.Scanner;

public class funcionariosMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        ArrayList<funcionario> lista = new ArrayList<>();
        int opcao;

        do {
            System.out.println("\n--- MENU DE FUNCIONARIOS ---");
            System.out.println("1. Cadastrar Gerente");
            System.out.println("2. Cadastrar Vendedor");
            System.out.println("3. Cadastrar Programador");
            System.out.println("4. Listar Contracheques");
            System.out.println("5. Folha de Pagamento Total");
            System.out.println("6. Buscar por Nome");
            System.out.println("0. Sair");
            System.out.print("Escolha: ");
            opcao = sc.nextInt();
            sc.nextLine(); 

            switch (opcao) {
                case 1:
                    System.out.print("Nome: "); 
                    String n1 = sc.nextLine();
                    
                    System.out.print("Salário: "); 
                    double s1 = sc.nextDouble();
                    
                    System.out.print("Bônus: "); 
                    double b1 = sc.nextDouble();
                    
                    lista.add(new gerente(n1, s1, b1));
                    break;
                case 2:
                    System.out.print("Nome: "); 
                    String n2 = sc.nextLine();
                    
                    System.out.print("Salário: "); 
                    double s2 = sc.nextDouble();
                    
                    System.out.print("Total Vendas: "); 
                    double v2 = sc.nextDouble();
                    
                    System.out.print("Comissão: "); 
                    double c2 = sc.nextDouble();
                    
                    lista.add(new vendedor(n2, s2, v2, c2));
                    break;
                case 3:
                    System.out.print("Nome: "); 
                    String n3 = sc.nextLine();
                    
                    System.out.print("Salário: "); 
                    double s3 = sc.nextDouble();
                    
                    System.out.print("Horas Extras: "); 
                    int h3 = sc.nextInt();
                    
                    System.out.print("Valor Hora: "); 
                    double vh3 = sc.nextDouble();
                    
                    lista.add(new programador(n3, s3, h3, vh3));
                    break;
                case 4:
                    for (funcionario f : lista) 
                    	f.exibirContraCheque();
                    break;
                case 5:
                    double total = 0;
                    for (funcionario f : lista) 
                    	total += f.calcularSalario();
                    System.out.println("Folha Total: R$ " + total);
                    break;
                case 6:
                    System.out.print("Nome para busca: "); 
                    String busca = sc.nextLine();
                    
                    for (funcionario f : lista) {
                        if (f.getNome().equalsIgnoreCase(busca)) 
                        	f.exibirContraCheque();
                    }
                    break;
            }
        } while (opcao != 0);
        System.out.println("Sistema encerrado.");
    }
}