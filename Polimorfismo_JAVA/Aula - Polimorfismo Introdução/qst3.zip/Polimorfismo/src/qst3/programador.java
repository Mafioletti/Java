package qst3;

public class programador extends funcionario{
	private int horasExtras;
	private double valorHoraExtra;
	
	public programador(String nome, double salarioBase, int horasExtras, double valorHoraExtra) {
		super(nome, salarioBase);
		this.horasExtras = horasExtras;
		this.valorHoraExtra = valorHoraExtra;
	}
	public int getHorasExtras() {
		return horasExtras;
	}

	public void setHorasExtras(int horasExtras) {
		this.horasExtras = horasExtras;
	}

	public double getValorHoraExtra() {
		return valorHoraExtra;
	}

	public void setValorHoraExtra(double valorHoraExtra) {
		this.valorHoraExtra = valorHoraExtra;
	}
	@Override
	public double calcularSalario(){
		return getSalarioBase() + (horasExtras * valorHoraExtra);
	}
	@Override
	public void exibirContraCheque() {
		System.out.println("Contra Cheque de PROGRAMADOR\n");
		super.exibirContraCheque();
		System.out.println("Horas extras : " + horasExtras);
		System.out.println("Valor hora extra: " + valorHoraExtra);
		System.out.println("Total a receber: " + calcularSalario() + "\n");
	}
}
