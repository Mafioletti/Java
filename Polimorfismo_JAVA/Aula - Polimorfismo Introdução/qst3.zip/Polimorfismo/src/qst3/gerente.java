package qst3;

public class gerente extends funcionario{
	private double bonusFixo;

	public gerente(String nome, double salarioBase, double bonusFixo) {
		super(nome, salarioBase);
		this.bonusFixo = bonusFixo;
	}

	public double getBonusFixo() {
		return bonusFixo;
	}

	public void setBonusFixo(double bonusFixo) {
		this.bonusFixo = bonusFixo;
	}
	@Override
	public double calcularSalario(){
		return getSalarioBase() + bonusFixo;
	}
	@Override
	public void exibirContraCheque() {
		System.out.println("Contra Cheque de GERENTE\n");
		super.exibirContraCheque();
		System.out.println("Bônus Fixo: " + bonusFixo);
		System.out.println("Total a receber: " + calcularSalario() + "\n");
	}
}
