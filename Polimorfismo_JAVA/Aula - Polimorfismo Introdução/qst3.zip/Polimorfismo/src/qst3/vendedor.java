package qst3;

public class vendedor extends funcionario{
	private double totalVendas;
	private double comissao;

	public vendedor(String nome, double salarioBase, double totalVendas, double comissao) {
		super(nome, salarioBase);
		this.totalVendas = totalVendas;
		this.comissao = comissao;
	}

	public double getTotalVendas() {
		return totalVendas;
	}

	public void setTotalVendas(double totalVendas) {
		this.totalVendas = totalVendas;
	}

	public double getComissao() {
		return comissao;
	}

	public void setComissao(double comissao) {
		this.comissao = comissao;
	}
	@Override
	public double calcularSalario() {
		return getSalarioBase() + (getTotalVendas() * (comissao/100));
	}
	@Override
	public void exibirContraCheque() {
		System.out.println("Contra Cheque de VENDEDOR\n");
		super.exibirContraCheque();
		System.out.println("Total de vendas : " + totalVendas);
		System.out.println("Comissão: " + comissao/100);
		System.out.println("Total a receber: " + calcularSalario() + "\n");
	}
}
