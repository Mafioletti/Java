package qst2;
public class papagaio extends animal {
    private String corPenas;

    public papagaio(String nome, int idade, double peso, String corPenas) {
        super(nome, idade, peso);
        this.corPenas = corPenas;
    }

    @Override
    public void emitirSom() {
        System.out.println(getNome() + " diz: Dedé, me dá 10 na prova");
    }

    @Override
    public String getTipoAlimento() {
        return "Onívoro - Sementes e frutas";
    }

    public void falar(String frase) {
        System.out.println(getNome() + " diz: " + frase);
    }
    public void exibirDados() {
		System.out.println("--Dados Papagaio--");
		super.exibirInfo();
	}
}