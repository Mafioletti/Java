package qst2;

public class leao extends animal{

	public leao(String nome, int idade, double peso) {
		super(nome, idade, peso);
	}
	@Override
	public void emitirSom() {	
		System.out.println("ROOAARR");
	}
	@Override
	public String getTipoAlimento() {
		return "Carnívoro - Carne";
	}
	public void rugir() {
		System.out.println("MAAAAAAAAAAAAAIIIIIIIIIINAAAAAAAAAAAAAAAARRRRRRRRRRRRDIIIIIIIIIIIIIIIIIIIII");
	}
	public void exibirDados() {
		System.out.println("--Dados Leão--");
		super.exibirInfo();
	}
}
