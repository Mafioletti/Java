package qst2;

public class animal {
	private String nome;
	private int idade;
	private double peso;
	
	public animal(String nome, int idade, double peso) {
		this.nome = nome;
		this.idade = idade;
		this.peso = peso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}
	//Metodos
	public void emitirSom() {
		System.out.println("");
	}
	
	public String getTipoAlimento() {
		return "Alimento";
	}
	
	public void exibirInfo() {
		System.out.println("Nome: " + nome);
		System.out.println("Idade: " + idade);
		System.out.println("Peso: " + peso);
		System.out.println("Tipo de Alimento: " + getTipoAlimento());
	}
}