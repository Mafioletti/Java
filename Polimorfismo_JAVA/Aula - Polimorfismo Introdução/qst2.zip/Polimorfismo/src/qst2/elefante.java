package qst2;

public class elefante extends animal{
	private double comprimentoElefante;

	public elefante(String nome, int idade, double peso, double comprimentoElefante) {
		super(nome, idade, peso);
		this.comprimentoElefante = comprimentoElefante;
	}

	public double getComprimentoElefante() {
		return comprimentoElefante;
	}

	public void setComprimentoElefante(double comprimentoElefante) {
		this.comprimentoElefante = comprimentoElefante;
	}
	
	@Override
	public void emitirSom() {	
		System.out.println("PRUUUUUU");
	}
	@Override
	public String getTipoAlimento() {
		return "Herbívoro - Folhas e Frutas";
	}
	public void exibirDados() {
		System.out.println("--Dados Elefante--");
		super.exibirInfo();
	}
}
