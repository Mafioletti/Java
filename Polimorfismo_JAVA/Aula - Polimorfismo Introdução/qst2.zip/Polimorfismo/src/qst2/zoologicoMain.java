package qst2;
import java.util.ArrayList;
import java.util.Scanner;

public class zoologicoMain {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        ArrayList<animal> zoologico = new ArrayList<>();
	        int opcao;

	        do {
	            System.out.println("\n--- MENU ZOOLÓGICO ---");
	            System.out.println("1. Adicionar Leão");
	            System.out.println("2. Adicionar Elefante");
	            System.out.println("3. Adicionar Papagaio");
	            System.out.println("4. Listar todos os animais");
	            System.out.println("5. Fazer todos os animais emitirem som");
	            System.out.println("6. Mostrar dieta de todos");
	            System.out.println("0. Sair");
	            System.out.print("Escolha: ");
	            opcao = sc.nextInt();
	            sc.nextLine();

	            switch (opcao) {
	                case 1:
	                	//pras outras atividades usei assim tbm, nL = nome Leao
	                    System.out.print("Nome: "); 
	                    String nL = sc.nextLine();
	                    System.out.print("Idade: "); 
	                    int iL = sc.nextInt();
	                    System.out.print("Peso: "); 
	                    double pL = sc.nextDouble();
	                    zoologico.add(new leao(nL, iL, pL));
	                    break;
	                case 2:
	                    System.out.print("Nome: "); 
	                    String nE = sc.nextLine();
	                    System.out.print("Idade: "); 
	                    int iE = sc.nextInt();
	                    System.out.print("Peso: "); 
	                    double pE = sc.nextDouble();
	                    System.out.print("Comprimento: "); 
	                    double cE = sc.nextDouble();
	                    zoologico.add(new elefante(nE, iE, pE, cE));
	                    break;
	                case 3:
	                    System.out.print("Nome: "); 
	                    String nP = sc.nextLine();
	                    System.out.print("Idade: "); 
	                    int iP = sc.nextInt();
	                    System.out.print("Peso: "); 
	                    double pP = sc.nextDouble();
	                    sc.nextLine();
	                    System.out.print("Cor das penas: "); 
	                    String cp = sc.nextLine();
	                    zoologico.add(new papagaio(nP, iP, pP, cp));
	                    break;
	                case 4:
	                    System.out.println("\n═══ LISTA DE ANIMAIS ═══");
	                    for (animal a : zoologico) 
	                    	a.exibirInfo();
	                    break;
	                case 5:
	                    System.out.println("\n═══ ANIMAIS EMITINDO SOM ═══");
	                    for (animal a : zoologico) 
	                    	a.emitirSom();
	                    break;
	                case 6:
	                    System.out.println("\n═══ DIETA DOS ANIMAIS ═══");
	                    for (animal a : zoologico) {
	                        System.out.println(a.getNome() + " come: " + a.getTipoAlimento());
	                    }
	                    break;
	            }
	        } while (opcao != 0);
	    }
	}