package qst1;
import java.util.*;

public class transporteMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<transporte> meiosTransporte = new ArrayList<>();
		int opcao, cont = 0;
		String enter;
		
		do {
			System.out.println("==MENU==\n1. Add Carro\n2. Add Ônibus\n3. Add Bicicleta\n4. Listar Transportes\n5. Calcular custo total\n0. Sair");
			opcao = sc.nextInt();
			
			switch(opcao) {
				case 1:
					System.out.println("Digite a distância percorrida pelo carro: ");
					double distanciaCarro = sc.nextDouble();
					System.out.println("Digite quantos passageiros tem no carro: ");
					int passageirosCarro = sc.nextInt();
					sc.nextLine();
					System.out.println("Digite o tipo de combustível do carro: ");
					String tipoCombustivel = sc.nextLine();
					
					transporte Carro = new carro(distanciaCarro, passageirosCarro, tipoCombustivel);
					meiosTransporte.add(Carro);
					
					System.out.println("Digite ENTER para continuar");
					enter = sc.nextLine();
					break;
					
				case 2:
					System.out.println("Digite a distância percorrida pelo ônibus: ");
					double distanciaOnibus= sc.nextDouble();
					System.out.println("Digite quantos passageiros tem no ônibus: ");
					int passageirosOnibus= sc.nextInt();
					System.out.println("Digite quantas linhas tem no onibus: ");
					int linhasOnibus = sc.nextInt();
					
					transporte Onibus = new onibus(distanciaOnibus, passageirosOnibus, linhasOnibus);
					meiosTransporte.add(Onibus);
					
					System.out.println("Digite ENTER para continuar");
					enter = sc.nextLine();
					break;
					
				case 3:
					System.out.println("Digite a distância percorrida pela bicicleta: ");
					double distanciaBike = sc.nextDouble();
					System.out.println("Digite quantos passageiros tem na Bicicleta: ");
					int passageirosBike = sc.nextInt();
					sc.nextLine();
					System.out.println("Digite o tipo de freio da bicicleta: ");
					String tipoFreio = sc.nextLine();
					
					transporte Bicicleta = new bicicleta(distanciaBike, passageirosBike, tipoFreio);
					meiosTransporte.add(Bicicleta);
					
					System.out.println("Digite ENTER para continuar");
					enter = sc.nextLine();
					break;
					
				case 4:
					if (meiosTransporte.isEmpty()) {
                        System.out.println("\nNenhum pagamento realizado ainda!");
                    } else {
                        System.out.println("\n═══ TODOS OS PAGAMENTOS ═══");
                        for (int i = 0; i < meiosTransporte.size(); i++) {
                            System.out.println("\n--- Transporte #" + (i + 1) + " ---");
                            // POLIMORFISMO EM AÇÃO!
                            // Cada objeto chama SUA versão do método!
                            meiosTransporte.get(i).exibirDetalhes();
                        }
                    }
                    break;
				case 5:
					if (meiosTransporte.isEmpty()) {
                        System.out.println("\nNenhum pagamento realizado ainda!");
                    } else {
                        double totalTaxas = 0;
                        System.out.println("\n═══ TAXAS POR PAGAMENTO ═══");
                        for (int i = 0; i < meiosTransporte.size(); i++) {
                            // POLIMORFISMO EM AÇÃO!
                            // Cada classe calcula sua taxa de forma diferente!
                            double taxa = meiosTransporte.get(i).calcularCusto();
                            totalTaxas += taxa;
                            System.out.println("Pagamento #" + (i + 1) + ": R$ " + 
                                             String.format("%.2f", taxa));
                        }
                        System.out.println("\nTOTAL DE TAXAS: R$ " + 
                                         String.format("%.2f", totalTaxas));
                    }
                    break;
				case 0:
					System.out.println("Saindo...");
					break;
				default:
					System.out.println("Opção inválida");
						
			}
		}while(opcao != 0);
	}
}
