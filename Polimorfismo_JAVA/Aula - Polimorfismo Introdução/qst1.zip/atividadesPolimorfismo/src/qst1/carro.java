package qst1;

public class carro extends transporte{
	private String tipoCombustivel;

	public carro(double distancia, int passageiros, String tipoCombustivel) {
		super(distancia, passageiros);
		this.tipoCombustivel = tipoCombustivel;
	}

	public String getTipoCombustivel() {
		return tipoCombustivel;
	}

	public void setTipoCombustivel(String tipoCombustivel) {
		this.tipoCombustivel = tipoCombustivel;
	}
	//Método
	@Override
	public double calcularCusto() {
		return getDistancia() * 1.50;
	}
	@Override
	public void exibirDetalhes() {
		super.exibirDetalhes();
		System.out.println("Tipo do combustível: " + tipoCombustivel);
	}
}
