package qst1;

public class transporte {
	private double distancia;
	private int passageiros;
	//construtor
	public transporte(double distancia, int passageiros) {
		this.distancia = distancia;
		this.passageiros = passageiros;
	}
	//getters setters
	public double getDistancia() {
		return distancia;
	}

	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}

	public int getPassageiros() {
		return passageiros;
	}

	public void setPassageiros(int passageiros) {
		this.passageiros = passageiros;
	}
	
	//Método
	public double calcularCusto() {
		return 0.0;
	}
	
	
	public void exibirDetalhes() {
		System.out.println("Distância: " + distancia);
		System.out.println("Passageiros: " + passageiros);
	}
	
}
