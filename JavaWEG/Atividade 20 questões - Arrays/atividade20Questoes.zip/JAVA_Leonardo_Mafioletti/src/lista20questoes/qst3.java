package lista20questoes;
import java.util.Scanner;

public class qst3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int valores[] = new int[15];
		
		for(int i = 0; i < valores.length; i++) {
			System.out.println("Digite um valor: ");
			valores[i] = sc.nextInt();
		}
		for(int i = 0; i < valores.length; i++) {
			if(valores[i] < 0) {
				valores[i] += (valores[i] * -1);
			}
		}
		System.out.println("O vetor atualizado é: ");
		for(int i = 0; i < valores.length; i++) {
			System.out.println(valores[i]);
		}
	}	
}
