package lista20questoes;
import java.util.*;

public class qst8 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int tamanho = 5;
		int vet1[] = new int [tamanho];
		int tamanho2 = 0;
		
		for(int i = 0; i < vet1.length; i++) {
			System.out.println("Digite número");
			vet1[i] = sc.nextInt();
			if(vet1[i] < 0) {
				tamanho2++;
			}
		}
		int vet2[] = new int [tamanho2];
		int index = 0;
		
		for(int i = 0; i < vet1.length; i++) {
			if(vet1[i] < 0) {
				vet2[index] = vet1[i];
				index++;
			}
		}
		for(int i = 0; i < tamanho2; i++) {
				vet2[i] *= - 1;
		}
		System.out.println("\n");
		for(int i = 0; i < tamanho2; i++) {
			System.out.println(vet2[i]);
		}
	}
}