package lista20questoes;
import java.util.Scanner;

public class qst4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int tamanho = 5;
		
		int vetor1[] = new int[tamanho];
		int vetor2[] = new int[tamanho];

		for(int i = 0; i < tamanho; i++) {
			System.out.println("Digite valor para vetor1: ");
			vetor1[i] = sc.nextInt();
			System.out.println("Digite valor para vetor2: ");
			vetor2[i] = sc.nextInt();
		}
		boolean igual = true;
		for(int i = 0; i < tamanho; i++) {
			if(vetor1[i] != vetor2[i]) {
				igual = false;
			}
		}
		if(igual) {
			System.out.println("São iguais!");
		} else {
			System.out.println("Tem alguma diferença!");
		}
	}

}
