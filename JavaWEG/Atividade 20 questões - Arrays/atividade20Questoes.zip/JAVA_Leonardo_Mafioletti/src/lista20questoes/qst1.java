package lista20questoes;
import java.util.Scanner;
import java.util.Arrays;

public class qst1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int mediaMes[] = new int[12];
		int maiorTemp = 0;
		String meses[] = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
		double menorTemp = Double.MAX_VALUE;
		int temp, posMaior = 0, posMenor = 0;
		
		for(int i = 0; i < mediaMes.length; i++) {
			System.out.println("Digite a temperatura média do " + (i + 1) + " mês: ");
			temp = sc.nextInt();
			mediaMes[i] += temp;
		}
		for(int i = 0; i < mediaMes.length; i++) {
			if(maiorTemp < mediaMes[i]) {
				maiorTemp = mediaMes[i];
				posMaior = i;
			}
		}
		for(int i = 0; i < mediaMes.length; i++) {
			if(menorTemp > mediaMes[i]) {
				menorTemp = mediaMes[i];
				posMenor = i;
			}
		}
		System.out.println("O mes com a temperatura mais alta: " + meses[posMaior]);
		System.out.println(maiorTemp + "ºC");
		System.out.println("O mes com a temperatura mais baixa: " + meses[posMenor]);
		System.out.println(menorTemp + "ºC");

	}
}
		

	


