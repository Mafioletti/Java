package lista20questoes;
import java.util.Scanner;

public class qst5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int vendedores = 10;
		
		int qtdPecasVendidas[] = new int[vendedores];
		int precoPorVendedor[] = new int [vendedores];
		int totalDePecas = 0;
		
		for(int i = 0; i < vendedores; i++) {
			System.out.println("Digite quantas o " + (i+1) + "º vendedor vendeu: ");
			qtdPecasVendidas[i] = sc.nextInt();
			System.out.println("Digite o preço das peças do " + (i+1) + "º vendedor: ");
			precoPorVendedor[i] = sc.nextInt();
		}
		for(int i = 0; i < vendedores; i++) {
			totalDePecas += qtdPecasVendidas[i];
		}
		System.out.println("\nTotal de peças vendidas: " + totalDePecas + "\n");
		
		for(int i = 0; i < vendedores; i++) {
			int totalPorVendedor = qtdPecasVendidas[i] * precoPorVendedor[i];
			System.out.println("O total da venda do " + (i+1) + "º vendedor: ");
			System.out.println(totalPorVendedor);
			
		}
	}
}
