package lista20questoes;
import java.util.Scanner;

public class qst10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Quantos contatos deseja cadastrar: ");
        int quantidade = sc.nextInt();
        sc.nextLine(); 

        String nomes[] = new String[quantidade];
        String telefones[] = new String[quantidade];

        for (int i = 0; i < quantidade; i++) {
            System.out.println("\nContato: " + (i + 1));
            System.out.print("Nome: ");
            nomes[i] = sc.nextLine();
            System.out.print("Telefone: ");
            telefones[i] = sc.nextLine();
        }
        while(true) {
	        System.out.print("\nDigite o nome que deseja consultar: ");
	        String busca = sc.nextLine();
	        
	        if(busca.equals("sair")) {
	        	System.out.println("Saindo...");
	        	break;
	        }
	
	        int indiceEncontrado = -1;
	
	        for (int i = 0; i < nomes.length; i++) {
	            if (nomes[i].equalsIgnoreCase(busca)) {
	                indiceEncontrado = i;
	                break;
	            }
	        }
	        if (indiceEncontrado != -1) {
	            System.out.println("Telefone de " + nomes[indiceEncontrado] + ": " + telefones[indiceEncontrado]);
	        } else {
	            System.out.println("Nome inexistente.");
	        }
        }
    }
}