package lista20questoes;
import java.util.Scanner;
import java.util.Random;

public class qst6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int soma = 0;
		int tamanho = 100;
		
		int vetor[] = new int[tamanho];
		Random gerador = new Random();
		
		for(int i = 0; i < vetor.length; i++) {
			vetor[i] = gerador.nextInt(1001);
			System.out.println(vetor[i]);
		}
		for(int i = 0; i < vetor.length; i++) {
			soma += vetor[i];
		}
		System.out.println("A media dos números sorteados é: " + soma / tamanho);
	}
}
